# CC Checker

[![Build status](https://ci2.dot.net/job/dotnet_codeformatter/job/master/job/innerloop/badge/icon)](https://ci2.dot.net/job/dotnet_codeformatter/job/master/job/innerloop/)

**PT-BR:** Testador de cartão de crédito código-aberto para estudos. 

**EN:** Open-source card credit checker for studies.


## Installation


```
1st: Download project and install on your website or localhost.
2nd: Open "check.php" with some IDE
3rd: Edit the Gateway information (URL, live and die messages, postfields...)
4th: Enjoy!
```


## Usage

```
Paste your credit card list into the text area and click "Start check"
```


## Credits

Vinicius Brokeh - _Developer_
